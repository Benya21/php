<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Schools</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <?php
    include_once "connect.php";
    $sql = "SELECT * FROM schools";
    $result = $conn->query($sql);
    
    ?>
<div class="container mt-3">
<h2><b>Schools</b></h2> <a href="schoolsform.php"><div class="add"><b>เพิ่มข้อมูล</b></div></a>
  <table class="table" >
    <thead>
      <tr>
        <th>รหัสสำนักวิชา</th>
        <th>โค้ดสำนักวิชา</th>
        <th>ชื่อสำนักวิชา</th>
        <th>เบอร์โทร</th>
        <th>ที่อยู่</th>
        <th>รหัสอาจารย์</th>
        <th></th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php 
      if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            ?>
              <tr>
                <td><?php echo $row['schoolID']?></td>
                <td><?php echo $row['schoolCode']?></td>
                <td><?php echo $row['schoolName']?></td>
                <td><?php echo $row['telNo']?></td>
                <td><?php echo $row['address']?></td>
                <td><?php echo $row['teacherID']?></td>
                <td><a href="delete_sc.php?schoolID=<?php echo $row['schoolID']?>">ลบ</a> </td>
                <td><a href="school_edit_form.php?schoolID=<?php echo $row['schoolID']?>">แก้ไข</a> </td>
              </tr>
            <?php 
            }
        }else{
          ?>
          <tr>
            <td colspan=6>Result is 0 record.</td>
          </tr>
          <?php 
        }
      ?>
    </tbody>
  </table>
</div>
<style>
    body{
      font-family: -apple-system, BlinkMacSystemFont, 'Ubuntu', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
      background-image:url("https://cdn.pixabay.com/photo/2015/03/19/22/42/background-681490_1280.jpg");
    }
    h2{
      border: 2px solid brown;
      font-family: 'Ubuntu', serif;
      background-image:url('https://i.pinimg.com/564x/84/63/54/8463540dc91bdae057998b5edc46a8aa.jpg');
      color:#273446;
      text-align:center;
      padding: 30px;
    }
    .add{
      width: 140px;
      background-color: #EDAB94;
      color: #235D3A;
      padding: 14px 30px;
      margin: 10px 0;
      border: none;
      border-radius: 5px;
      cursor:pointer;
    }
    table, td, th {
      border: 2px solid purple;
    }
    table{
      background-color:#FCF4DB;
      width : 100%;
      text-align:center;
    }
</style>
</body>
</html>