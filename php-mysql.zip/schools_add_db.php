<?php
    include_once "connect.php";
    //$sql = "SELECT * FROM Owner";
    //$result = $conn->query($sql);
    //********Code insert data base********//
    $schoolID = $_POST["schoolID"];
    $schoolCode = $_POST["schoolCode"];
    $schoolName = $_POST["schoolName"];
    $telNo = $_POST["telNo"];
    $address = $_POST["address"];
    $teacherID = $_POST["teacherID"];

    if(strlen($schoolID) >0 && strlen($schoolCode) >0 && strlen($schoolName)>0 && strlen($telNo) >0 && strlen($address)>0 && strlen($teacherID)>0){
        $sql = "INSERT INTO `schools`( `schoolID`, `schoolCode`, `schoolName`, `telNo`, `address`, `teacherID`) VALUES ('$schoolID','$schoolCode','$schoolName','$telNo','$address','$teacherID')";
        $conn->query($sql);
    }

    header( "location: http://localhost/IMI62-231/php-mysql/schools.php" );
    exit(0);

    
    
    ?>