<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.2/dist/js/bootstrap.bundle.min.js"></script>
    <title>Schools</title>
</head>
<body>
<div class="container">
  <h2>บันทึกข้อมูล</h2>
  <form action="schools_add_db.php" method="post">
    <div class="form-group">
      <label for="schoolID">รหัสสำนักวิชา:</label>
      <input type="text" class="form-control" id="schoolID" placeholder="กรุณาใส่รหัสสำนักวิชา" name="schoolID" require>
    </div>
    <div class="form-group">
      <label for="schoolCode">โค้ดสำนักวิชา:</label>
      <input type="text" class="form-control" id="schoolCode" placeholder="กรุณาใส่โค้ดสำนักวิชา" name="schoolCode" require>
    </div>
    <div class="form-group">
      <label for="schoolName">ชื่อสำนักวิชา:</label>
      <input type="text" class="form-control" id="schoolName" placeholder="กรุณาใส่ชื่อสำนักวิชา" name="schoolName" require>
    </div>
    <div class="form-group">
      <label for="telNo">เบอร์โทร:</label>
      <input type="text" class="form-control" id="telNo" placeholder="กรุณาใส่เบอร์โทร" name="telNo" require>
    </div>
    <div class="form-group">
      <label for="address">ที่อยู่:</label>
      <input type="text" class="form-control" id="address" placeholder="กรุณาใส่ที่อยู่" name="address" require>
    </div>
    <div class="form-group">
      <label for="teacherID">รหัสอาจารย์:</label>
      <input type="text" class="form-control" id="teacherID" placeholder="กรุณาใส่รหัสอาจารย์" name="teacherID" require>
    </div>
    <button type="submit" class="btn"><b>Submit</b></button>
  </form>
</div>
<style>
    body{
      font-family: -apple-system, BlinkMacSystemFont, 'Ubuntu', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
      background-image:url("https://cdn.pixabay.com/photo/2015/03/19/22/42/background-681490_1280.jpg");
    }
    h2{
      border: 2px solid brown;
      font-family: 'Ubuntu', serif;
      background-image:url('https://i.pinimg.com/564x/84/63/54/8463540dc91bdae057998b5edc46a8aa.jpg');
      color:#273446;
      text-align:center;
      padding: 30px;
    }
    .btn{
      width: 140px;
      background-color: #EDAB94;
      color: #235D3A;
      padding: 14px 30px;
      margin: 10px 0;
      border: none;
      border-radius: 5px;
      cursor:pointer;
    }
    
</style>  
</body>
</html>