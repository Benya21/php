<?php
    include_once "connect.php";
    
    $schoolID = $_GET['schoolID'];
    if(strlen($schoolID) >0){
        $sql = "DELETE FROM schools WHERE schoolID  = '$schoolID' ";
        //echo $sql;
        $conn->query($sql);
    }

    header( "location: http://localhost/IMI62-231/php-mysql/schools.php" );
    exit(0);
    
    ?>